from . import RC, Maths, Utilities, DataHandling, TrainingModels

__all__ = ["RC", "Maths", "Utilities", "DataHandling", "TrainingModels"]

__version__ = "0.1.14" # change this for releases