from . import RC, Maths, Utilities, DataHandling, TrainingModels

__all__ = ["RC", "Maths", "Utilities", "DataHandling", "TrainingModels"]

__version__ = "0.1.13" # change this for releases